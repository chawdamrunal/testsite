---
name: Submit Template
about: Submit nuclei template using issue
title: "[nuclei-template] "
labels: ''
assignees: ''

---

**Template Details**

```
nuclei template goes here
```
